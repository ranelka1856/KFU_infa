from django.contrib import admin

# Register your models here.
from main.models import CalcHistory

# Register your models here.

admin.site.register(CalcHistory)