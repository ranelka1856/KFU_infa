
from django.shortcuts import render
from django.forms import model_to_dict
from django.shortcuts import render
from django.views import View
from rest_framework.response import Response
from rest_framework.views import APIView
from main.models import CalcHistory
# Create your views here.


class CalcHistory_v(APIView):
    def get(self, request):
        calc_obj = CalcHistory.objects.get(id=1)
        return Response(model_to_dict(calc_obj))

class CalcHistory_post(APIView):
    def get(self, request):
        calc_obj = CalcHistory.objects.get(id=1)
        return Response(model_to_dict(calc_obj))
    def post(self, request):
        calc_obj = CalcHistory.objects.get(id=1)
        calc_obj.val1 = request.data['val1']
        calc_obj.val2 = request.data['val2']
        calc_obj.operator = request.data['operator']
        return Response(model_to_dict(calc_obj))
# {"val1": 3.0,"val2": 4.9, "operator": "-"}


class HtmlView(View):
    def get(self, request):
        calc_obj = CalcHistory.objects.filter(id=1)
        return render(request, "q.html", {"q": calc_obj})
