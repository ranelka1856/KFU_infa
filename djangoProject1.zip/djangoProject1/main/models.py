from django.db import models

# Create your models here.

class CalcHistory(models.Model):
    id = models.AutoField(
        primary_key=True
    )
    val1 = models.FloatField(
        default=0,
        verbose_name='Первое значение'
    )
    val2 = models.FloatField(
        default=0,
        verbose_name='Второе значение'
    )
    created_at = models.DateTimeField(
        default=0,
        verbose_name='Когда создали'
    )
    result = models.FloatField(
        default=0,
        verbose_name='Результат'
    )
    operator = models.CharField(
        max_length=1,
        verbose_name='Оператор'
    )

    def __str__(self):
        return f'Id:{self.id}'